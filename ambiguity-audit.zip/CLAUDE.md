# Ambiguity Audit — plugin-level instructions

When this plugin is active, treat the two skills as halves of a single workflow rather than as independent tools.

## The combined workflow

When a user pastes a legal text and asks for an audit, a stress test, an issue spot, a "where will this be litigated" memo, or any similar request:

1. **Run the analysis first.** Invoke `interpretive-ambiguity-stress-test`. Select the profile (contract, statute, regulation, opinion). Produce structured scenarios.
2. **Ask about the deliverable.** Once the analysis is done, ask: "How would you like this delivered? Multi-page website (default), single-page interactive site, Word document, PowerPoint deck, or LaTeX PDF?" Don't render until the user confirms.
3. **Render via `ambiguity-report`.** Pass the structured output of stage 1 into stage 2 as the input. The skill handles the rest.

When a user pastes an already-existing audit (their own markdown, a memo, a draft), skip stage 1 and go straight to `ambiguity-report`. The report skill is built to cope with semi-structured and unstructured input.

## Citation verification via CourtListener

If the user has connected CourtListener (or Descrybe), the workflow gains a third stage:

- **After analysis, before rendering**, extract the case citations referenced in each scenario's `likely_outcome` field.
- For each citation, call the connector's citation-verification tool to check that the case is still good law and has not been overruled, distinguished, or recently re-interpreted.
- Flag any citation that fails verification in a research note at the bottom of the audit, and update the `likely_outcome` field if a citation has been overruled.
- If no legal-research connector is set up, skip this step and add a methodology note saying "citations were not verified — install the CourtListener connector for inline cite-checking."

For Supreme Court opinions specifically, also check whether the opinion itself has been subsequently distinguished, narrowed, or overruled. The audit's predictions about future scenarios are only as good as the holding being audited.

## When to default to retrospective mode

The opinion profile has two modes — prospective (the default, for draft opinions and audits run by the authoring chambers) and retrospective (for final, decided opinions audited by litigators or lower courts).

- If the user is auditing an opinion published in the last 30 days **and** the user identifies as a clerk, a chambers attorney, or "the authoring court," default to prospective mode. The output is a tightening of the opinion's own language.
- If the user is auditing any final opinion **and** identifies as a litigator, lower-court judge, advocate, or law professor, default to retrospective mode. The output is an argument pair for each scenario, not a redraft.
- If the user has not identified their role, ask one short question: "Are you the court (drafting / about to release) or a litigator/lower-court reader (working with the final opinion)?" — and let the answer pick the mode.

## When the user wants design tweaks

The report skill saves a canonical `spec.json` alongside every deliverable. Design tweaks (different accent color, different font, different brand label) should re-render from the saved `spec.json` rather than re-running the analysis. This is fast and deterministic.

## What this plugin does not do

The user-facing README enumerates this. Briefly: no validity audits, no current-law verification without a connector, no drafting of new texts from scratch, and no certainty about predicted outcomes.

If the user asks for any of these, name them clearly and either decline or offer a related but bounded service ("I can audit ambiguity but not unconstitutionality — would you like the ambiguity audit, or do you want me to use a different skill for the constitutional-validity question?").
