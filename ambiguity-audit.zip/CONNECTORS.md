# Connectors

This plugin works without any connectors, but two are recommended for citation verification and current-law checking.

## Connectors for this plugin

| Category | Placeholder | Included servers | Other options |
|----------|-------------|-----------------|---------------|
| Legal research (corpus) | `~~case-law` | CourtListener | Westlaw, Lexis+, Bloomberg Law |
| Legal research (concept) | `~~legal-concept-search` | Descrybe | Casetext (CoCounsel), Vincent AI |

## Why these matter

The `interpretive-ambiguity-stress-test` skill identifies seams in a legal text where future litigation is likely. Several of the audit's outputs depend on whether the precedent line cited in the analysis is still good law:

- The **likely_outcome** field predicts how a court will resolve the seam, often by citing a controlling case or doctrine. If that case has been overruled, distinguished, or recently re-interpreted, the prediction is wrong.
- The **research note** in the methodology section flags scenarios that depend on subsequent statutes, regulations, or carveouts.

The `ambiguity-report` skill renders the audit but does not itself check currency. Connecting CourtListener (or Descrybe) lets the audit do the cite-check inline.

## How tool references work

The skills in this plugin describe research moves in terms of categories. When a skill says "verify the citation via the legal-research connector," it means *any* connected MCP server in the case-law category. CourtListener is the default because it's free and broadly trusted, but Descrybe (concept-first) is a sensible second.

## What to set up

If you only set up one connector, set up CourtListener. The plugin's research workflow is built around its API:

- `search` — find a case by name or concept
- `extract_citations` / `analyze_citations` — pull citations out of text and check their status
- `call_endpoint` — fetch fields not indexed in search

Authentication is handled by the MCP server itself; the plugin does not need to know about API keys.
