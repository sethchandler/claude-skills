# Ambiguity Audit

A two-skill plugin for adversarially stress-testing legal texts and turning the result into a polished deliverable.

> **Disclaimer.** This plugin assists with legal analysis but does not provide legal advice. The audit identifies seams where litigation will likely originate; it does not predict outcomes with certainty, verify cite-checking, or substitute for the judgment of a licensed attorney. The plugin's likely-outcome predictions are hedged but not infallible. Always verify conclusions with a qualified lawyer before relying on them.

## What this plugin does

It takes a legal text — a contract, a statute, a regulation, or a judicial opinion — and finds the places where the people governed by it will later disagree about what it means. For each weak seam, it produces a concrete dispute: realistic facts, both sides' arguments, the likely outcome, and either a proposed redraft (for contracts, statutes, regulations, and draft opinions) or an argument pair (for final opinions). The result is then rendered into a website, Word document, PowerPoint deck, or typeset PDF for the audience that needs it.

The plugin is built around one principle: **the audit's job is to invent the two people who will fight, not to flag vague words.** A linter says "this term is vague." This plugin instead constructs the two lawyers who would each, plausibly, win if their reading prevailed — and the money or liberty riding on the answer.

## The two skills

| Skill | What it does |
|-------|--------------|
| `interpretive-ambiguity-stress-test` | The analysis. Reads the legal text. Identifies seams. Produces scenarios with the seven canonical fields (title, anchors, family, situation, weak point, likely outcome, redraft or argument pair). Selects a domain profile — contract, statute, regulation, or opinion — that controls the defect taxonomy, the interpretive doctrines, and the quality bar. |
| `ambiguity-report` | The deliverable. Takes the analysis (structured or semi-structured) and renders it in one of five formats: multi-page website (default, deployable to Netlify), single-page interactive site, Microsoft Word document, PowerPoint deck, or LaTeX/PDF. Visual design is opinionated but the user can override colors, fonts, and brand label. |

The skills are decoupled: the report skill works on the stress-test skill's output but accepts any structured ambiguity analysis. The stress-test skill produces machine-readable output but is useful on its own.

## Installation

```
claude plugins add <user>/ambiguity-audit
```

After install, restart your session so the skills become available.

## Quick start

### 1. Identify the legal text

The text can be:
- A contract clause or full agreement
- A statute or code section (any jurisdiction)
- A regulation
- A judicial opinion (any court)

Paste the text into chat, attach a PDF, or point Claude at a URL.

### 2. Run the audit

```
/ambiguity-audit:interpretive-ambiguity-stress-test
```

Or, in conversational form: "Run an ambiguity audit on this contract" / "Stress-test § 4 of this statute" / "Find the seams in this Supreme Court opinion."

The audit runs through four stages — parse, scan, construct, output — and produces a structured markdown report with one scenario per surviving defect.

### 3. Render the result

```
/ambiguity-audit:ambiguity-report
```

Or: "Turn this into a website" / "Make a PowerPoint of the scenarios" / "Render as a Word doc for our partner to review."

Pick from the five output formats. The default is a multi-page website ready to drag onto Netlify Drop. The skill saves a canonical `spec.json` alongside the deliverable, so design tweaks can re-render without rebuilding the analysis.

## Recommended connectors

The plugin works without any external connectors, but two are recommended:

- **CourtListener** (default). For verifying citations referenced in audit scenarios and for checking whether the precedent line beneath a stressed opinion is currently good law.
- **Descrybe**. Concept-first legal research as a complement to CourtListener's corpus-first interface.

See [CONNECTORS.md](CONNECTORS.md) for the full configuration.

## What each format optimizes for

| Format | Best for |
|--------|----------|
| Multi-page website (default) | A reference site readers come back to; citeable per-scenario URLs; share by link; deploy to Netlify in two clicks. |
| Single-page interactive site | A dashboard view; everything cross-linked by click; good for an in-house tool or an exhibit. |
| Microsoft Word document | A litigator or legislator who will read in Word; reviewable with tracked changes; printable. |
| PowerPoint deck | A meeting, a CLE, a pitch — one slide per scenario, family color on the band, speaker notes carry the analysis. |
| LaTeX → PDF | A typeset deliverable for an academic audience; footnotes for the analysis layer; submission-quality typography. |

## What the plugin does not do

- It does not predict outcomes with certainty. Likely-outcome predictions are hedged and should be treated as starting points for analysis.
- It does not verify current law. Set up a legal-research connector (CourtListener or Descrybe) for that.
- It does not assess validity. A contract can be perfectly unambiguous and wholly unenforceable; a statute can be unambiguous and unconstitutional. The plugin's gauntlet families reach slightly into validity (the constitutional-avoidance family for statutes, for example), but a systematic legality opinion is a separate pass.
- It does not draft new legal text from scratch. The redraft field proposes amendments that close detected seams; it does not write a new contract or a new statute.

## Acknowledgements

This plugin grew out of a workflow developed at the University of Houston Law Center. The interpretive-ambiguity stress-test profile structure (contract, statute, regulation, opinion) was shaped by classroom hypotheticals and academic legal-writing critique sessions. Built and maintained by Seth J. Chandler.

## License

Apache 2.0. See [LICENSE](LICENSE).
