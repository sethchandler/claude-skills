---
name: ambiguity-report
description: Turn an interpretive-ambiguity audit of a legal text — contract, statute, regulation, or judicial opinion — into a polished deliverable. Produces a multi-page website (default), a single-page interactive site, a Microsoft Word document, a PowerPoint deck, or a LaTeX/PDF. Use whenever a user has a stress-test result, ambiguity audit, or "where will this be litigated" scenarios and wants to publish, present, or share them. Triggers on "publish the audit," "make a report from this," "turn this into a website / deck / brief / Word doc," "make a Netlify site," "build slides of these ambiguities," "render the scenarios," "package this stress test," "produce a LaTeX version," and similar. Pairs with the interpretive-ambiguity-stress-test skill (the underlying analysis) but works on any structured or semi-structured ambiguity analysis. Visual design is opinionated but the user can override colors, fonts, and brand label.
---

# Ambiguity Report

Take an interpretive-ambiguity analysis of a legal text and turn it into a polished deliverable in one of five formats: multi-page website (the default), single-page interactive website, Microsoft Word document, PowerPoint deck, or LaTeX/PDF document.

The skill's central insight: **the data is the same across formats, the rendering is not.** An ambiguity analysis is a set of scenarios — each with a situation, two opposed positions, a weak point in the text, a likely outcome, and a proposed redraft — anchored to provisions of a source text. Once that data is captured in the canonical spec, the right format follows from how the deliverable will be used.

## Workflow

This skill has four stages. Stages 1–3 are setup; stage 4 is rendering.

- **Stage 1 — Identify the input.** Determine what kind of analysis the user is handing over. Three common shapes: (a) the structured markdown output of the `interpretive-ambiguity-stress-test` skill; (b) a less-formal report or memo with scenarios identified but not all seven canonical fields filled in; (c) raw prose that names some ambiguities but isn't formatted as scenarios at all. The strategy for each shape differs — see `references/parsing-unstructured.md`.
- **Stage 2 — Build the canonical spec.** Convert the input into a structured JSON spec that every renderer can consume. The schema is in `references/data-format.md`. Fill in defaults for missing fields rather than blocking on completeness, and surface to the user what was inferred so they can correct.
- **Stage 3 — Choose the format and design.** Confirm with the user which format they want (default: multi-page website). Capture any design overrides (accent color, fonts, brand label). Most users care only about format and accent color; almost everything else has a sensible default.
- **Stage 4 — Render.** Delegate to the right renderer. The website and LaTeX paths use the bundled generator scripts (`scripts/generate_site.py` and `scripts/generate_latex.py`). The Word and PowerPoint paths delegate to the existing `docx` and `pptx` skills with content structured for those formats. Format-specific guidance lives in `references/format-{website,docx,pptx,latex}.md`.

## Stage 1 — Identify the input

Look at what the user supplied. Three signatures to watch for:

**Signature A — structured stress-test output.** Markdown with sections titled like "## Scenarios" and individual scenarios under headers like "### S-1 —", each containing labeled fields ("**Anchors:**", "**Defect family:**", "**Weak point:**", "**Likely outcome:**", "**Redraft:**"). Often produced by the interpretive-ambiguity-stress-test skill. This is the easy case — parse directly into the canonical spec.

**Signature B — semi-structured report.** Numbered ambiguities or issues in prose, each with a paragraph or two of explanation. The seven canonical fields may not all be present — the "situation" and "weak point" might be merged; the redraft might be missing entirely. Extract what's there, flag what's missing, and either infer reasonable defaults or ask the user. See `references/parsing-unstructured.md`.

**Signature C — raw prose.** A memo, a draft, or a transcript discussing "places this text is unclear." No formal scenario structure. The skill must do more work: identify candidate ambiguities, split into discrete scenarios, propose a defect family for each. Confirm the extraction with the user before rendering — the rendered output is only as good as the structure.

In all three cases, the source text (the statute / contract / regulation / opinion being audited) needs to be identified. If the input does not include the full source text, ask the user to provide it. The skill can render scenarios without the source, but the result is much weaker — the source is the spine of the document.

## Stage 2 — Build the canonical spec

The spec schema is documented fully in `references/data-format.md`. The top-level shape:

```
{
  "meta": { title, subtitle, kicker, audit_date, profile, brand_short, brand_sub },
  "design": { accent_color, accent_soft, dept_color, adv_color, ... },
  "source": { name, sections: [ { id, label, subhead, text, subprovisions: [...] } ] },
  "families": [ { key, label, description, diagnostic } ],
  "scenarios": [ { id, title, tagline, anchors, families, situation, positions, weak_point, likely_outcome, redraft } ],
  "coverage_list": [ { label, note } ],
  "methodology": { workflow, filter, profile, scope, research, provenance }
}
```

Build this iteratively: start with the source text and the scenarios (the two most important), then add the optional sections (families, coverage list, methodology) if the input supplied them or if the user wants them. The `families` block is auto-derivable from the family keys used in scenarios; supply a default label table and let the user override descriptions.

**Anchor IDs.** Every scenario links to one or more provisions of the source. Anchor IDs must match the IDs assigned to provisions in `source.sections`. Use a consistent scheme — for statutes, ID by subdivision marker (`a`, `b1`, `b2`, `b6B`, `c`); for contracts, by clause number (`s2_1`, `s2_1_a`); for opinions, by paragraph or holding-fragment (`p3`, `holding_1`).

Save the spec to `<output-dir>/spec.json` before rendering. This makes the rendering deterministic and re-runnable when the user wants design tweaks without rebuilding the analysis.

## Stage 3 — Choose the format and design

Ask the user which format they want unless they already said. The five options:

| Format | When to use |
|--------|-------------|
| Multi-page website (default) | Citeable per-scenario URLs; reference site readers will come back to; deployable to Netlify or any static host. |
| Single-page interactive website | Dashboard view of everything at once; cross-linking by click; good for an in-house tool or an exhibit. |
| Microsoft Word document | A litigator or legislator who will read in Word; reviewable with tracked changes; printable. |
| PowerPoint deck | A meeting, a CLE, a pitch — one scenario per slide, family color on the band, speaker notes carrying the analysis. |
| LaTeX → PDF | A typeset deliverable for an academic audience; footnotes for analysis; submission-quality typography. |

**Design tokens.** Five values cover 95% of customization needs: `accent_color` (the primary brand color — red-orange burnt-sienna by default), `accent_soft` (a lighter complement, auto-derived if not supplied), `dept_color` (Position A side panel — slate blue by default), `adv_color` (Position B side panel — usually mirrors accent), and `background_color` (warm cream by default). Fonts default to Fraunces / Inter / Crimson Pro on the web, system serifs in Word, and Latin Modern in LaTeX. Family color palette is fixed but can be overridden via `design.family_palette`.

If the user specifies a brand context — "for a corporate audit," "in our firm's colors," "for a state legislator" — match the palette to that. A corporate audit reads cleaner with navy + slate; legislative work reads better with the warmer default; academic work can lean to monochrome.

## Stage 4 — Render

Each format has its own reference file with detailed instructions. Read the relevant one before rendering. The rough invocations:

**Website** (multi or single page) — bundled script:
```bash
python scripts/generate_site.py \
  --spec <output-dir>/spec.json \
  --out <output-dir>/site \
  --mode multi    # or "single"
```
The script emits a complete static site (HTML + CSS) ready to upload to Netlify. See `references/format-website.md`.

**Word document** — delegate to the `docx` skill. Read `references/format-docx.md` for the document structure (title page, executive summary, statute-as-block, scenarios as level-2 sections, redrafts appendix, methodology appendix). Build via the docx skill's python-docx pattern.

**PowerPoint deck** — delegate to the `pptx` skill. Read `references/format-pptx.md` for the slide structure (title, statute overview, one slide per scenario with family-color band, redrafts slide, methodology slide). Speaker notes carry the analysis. Build via the pptx skill's tooling.

**LaTeX** — bundled script:
```bash
python scripts/generate_latex.py \
  --spec <output-dir>/spec.json \
  --out <output-dir>/report.tex
```
The script emits a self-contained `.tex` file using the article class with a clean preamble. The user can compile to PDF with `latexmk -pdf report.tex` (or pdflatex twice). See `references/format-latex.md`.

**All formats at once.** If the user asks for all formats from one invocation, run the renderers in sequence and present each output. This is useful when a deliverable is going to a mixed audience (the litigator wants the Word doc, the colleague wants the link to the site, the meeting wants the deck).

## Output organization

Default output directory: `<source-name>-ambiguity/` in the workspace folder if one is connected, otherwise in the temporary outputs folder. Within it:

```
<source-name>-ambiguity/
├── spec.json              # The canonical spec — re-renderable
├── site/                  # If website was requested (multi or single)
├── report.docx            # If Word was requested
├── deck.pptx              # If PowerPoint was requested
├── report.tex             # If LaTeX was requested
└── report.pdf             # Compiled if LaTeX was requested and compilation succeeded
```

When presenting outputs, use `mcp__cowork__present_files` on each produced file. For the website, present `site/index.html` — the user can drag the whole `site/` folder to Netlify Drop to deploy.

## What this skill does not do

- It does not perform the ambiguity analysis itself. That is the job of `interpretive-ambiguity-stress-test`. This skill turns analysis into a deliverable; it does not generate scenarios from a bare legal text.
- It does not edit the source text — only quotes it.
- It does not verify citations or check current law. If the underlying analysis relies on case law that may have changed, the skill should add a research note to the methodology section but cannot itself confirm currency. Cite-checking would be a separate pass.
- It does not produce printed-paper layouts. The LaTeX path produces a screen-readable PDF; print-specific layout (booklet format, court submission formats) is the province of more specialized skills like `scotus-amicus`.

## When the user asks for design tweaks

Re-render from the saved `spec.json` with the new design tokens. Do not re-parse the input. This is what makes the spec file worth saving — design iteration is fast and deterministic.

## Pointers to references

- `references/data-format.md` — the canonical spec schema. Read this in Stage 2 before building the spec.
- `references/parsing-unstructured.md` — heuristics for extracting scenarios from less-structured input. Read this in Stage 1 if the input is Signature B or C.
- `references/format-website.md` — how the website renderer works, deployment to Netlify, the design system.
- `references/format-docx.md` — Word document structure, delegated to the docx skill.
- `references/format-pptx.md` — PowerPoint structure, delegated to the pptx skill.
- `references/format-latex.md` — LaTeX preamble, document class, compilation.
